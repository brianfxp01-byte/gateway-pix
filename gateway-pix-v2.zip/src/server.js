const app = require('./app')
app.listen(3000, () => console.log('Gateway Pix v2 rodando'))