const express = require('express')
const app = express()
app.use(express.json())
app.use('/pix', require('./routes/pix.routes'))
app.use('/withdraw', require('./routes/withdraw.routes'))
module.exports = app